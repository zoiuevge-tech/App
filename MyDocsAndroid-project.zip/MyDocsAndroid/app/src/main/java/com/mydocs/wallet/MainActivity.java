package com.mydocs.wallet;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.view.*;
import android.widget.*;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import java.io.*;
import java.security.MessageDigest;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import java.util.concurrent.Executor;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE = 100;
    private String selectedDoc = "";
    private LinearLayout root;
    private final String[] docs = {"الهوية الشخصية - الوجه الأمامي", "الهوية الشخصية - الوجه الخلفي", "رخصة القيادة", "رخصة السيارة", "وثيقة أخرى"};
    private File docsDir;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        docsDir = new File(getFilesDir(), "documents");
        if (!docsDir.exists()) docsDir.mkdirs();
        if (!getPreferences(0).contains("pin_hash")) setupPin(); else unlock();
    }

    private void setupPin() {
        final EditText pin = pinInput("أنشئ رقمًا سريًا من 4 أرقام على الأقل");
        new AlertDialog.Builder(this).setTitle("إعداد محفظتي").setMessage("الوثائق تحفظ داخل التطبيق على هذا الجهاز.")
          .setView(pin).setCancelable(false).setPositiveButton("حفظ", (d,w) -> {
              String p = pin.getText().toString();
              if (p.length() < 4) { toast("الرقم السري يجب أن يكون 4 أرقام أو أكثر"); setupPin(); return; }
              getPreferences(0).edit().putString("pin_hash", hash(p)).apply(); showHome();
          }).show();
    }

    private EditText pinInput(String hint) {
        EditText e = new EditText(this); e.setHint(hint); e.setInputType(2); e.setPadding(40,20,40,20); return e;
    }

    private void unlock() {
        boolean canBio = BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS;
        if (canBio) {
            Executor executor = ContextCompat.getMainExecutor(this);
            BiometricPrompt prompt = new BiometricPrompt(this, executor, new BiometricPrompt.AuthenticationCallback() {
                @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) { showHome(); }
                @Override public void onAuthenticationError(int code, CharSequence msg) { askPin(); }
            });
            prompt.authenticate(new BiometricPrompt.PromptInfo.Builder().setTitle("فتح محفظتي").setSubtitle("استخدم بصمتك أو رقمك السري").setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG).setNegativeButtonText("استخدام الرقم السري").build());
        } else askPin();
    }

    private void askPin() {
        EditText pin = pinInput("الرقم السري");
        new AlertDialog.Builder(this).setTitle("محفظتي مقفلة").setView(pin).setCancelable(false).setPositiveButton("فتح", (d,w) -> {
            if (hash(pin.getText().toString()).equals(getPreferences(0).getString("pin_hash", ""))) showHome();
            else { toast("الرقم السري غير صحيح"); askPin(); }
        }).setNegativeButton("إغلاق", (d,w) -> finish()).show();
    }

    private void showHome() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,28,28,24); root.setBackgroundColor(0xFFF6F8FA);
        TextView title = new TextView(this); title.setText("محفظتي"); title.setTextSize(30); title.setTextColor(0xFF123B4A); title.setGravity(Gravity.CENTER); title.setPadding(0,16,0,20); root.addView(title);
        TextView subtitle = new TextView(this); subtitle.setText("وثائقك الشخصية — محفوظة على جهازك"); subtitle.setTextSize(14); subtitle.setGravity(Gravity.CENTER); subtitle.setPadding(0,0,0,20); root.addView(subtitle);
        for (String doc : docs) {
            Button b = new Button(this); b.setText(doc + (fileFor(doc).exists() ? "  ✓" : "  +")); b.setAllCaps(false); b.setTextSize(16);
            b.setOnClickListener(v -> showDocOptions(doc)); root.addView(b, new LinearLayout.LayoutParams(-1, -2));
        }
        Button lock = new Button(this); lock.setText("قفل التطبيق"); lock.setAllCaps(false); lock.setOnClickListener(v -> { setContentView(new View(this)); askPin(); }); root.addView(lock);
        TextView note = new TextView(this); note.setText("مهم: هذه نسخة أولية. احتفظ بنسخة آمنة من الوثائق الأصلية؛ حذف التطبيق قد يحذف الملفات المحفوظة داخله."); note.setTextSize(12); note.setPadding(4,24,4,0); root.addView(note);
        setContentView(root);
    }

    private void showDocOptions(String doc) {
        File f = fileFor(doc);
        String[] opts = f.exists() ? new String[]{"عرض الوثيقة", "استبدال الصورة", "حذف الوثيقة"} : new String[]{"إضافة صورة"};
        new AlertDialog.Builder(this).setTitle(doc).setItems(opts, (d,which) -> {
            if (!f.exists()) pick(doc);
            else if (which == 0) viewFile(f);
            else if (which == 1) pick(doc);
            else new AlertDialog.Builder(this).setMessage("متأكد من حذف الوثيقة؟").setNegativeButton("إلغاء",null).setPositiveButton("حذف",(dd,ww)->{f.delete(); showHome();}).show();
        }).show();
    }

    private void pick(String doc) { selectedDoc = doc; Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i, PICK_IMAGE); }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try (InputStream in = getContentResolver().openInputStream(uri); ByteArrayOutputStream bytes = new ByteArrayOutputStream()) {
                byte[] buf = new byte[8192]; int n; while ((n=in.read(buf))>0) bytes.write(buf,0,n);
                byte[] encrypted = encrypt(bytes.toByteArray());
                try (FileOutputStream out = new FileOutputStream(fileFor(selectedDoc))) { out.write(encrypted); }
                toast("تم حفظ الوثيقة مشفّرة داخل التطبيق"); showHome();
            } catch (Exception e) { toast("تعذر حفظ الصورة أو تشفيرها"); }
        }
    }

    private File fileFor(String doc) { return new File(docsDir, Integer.toHexString(doc.hashCode()) + ".enc"); }
    private void viewFile(File f) {
        try {
            byte[] encrypted = new byte[(int) f.length()];
            try (FileInputStream in = new FileInputStream(f)) { int off=0, n; while(off<encrypted.length && (n=in.read(encrypted,off,encrypted.length-off))>0) off+=n; }
            byte[] plain = decrypt(encrypted);
            android.graphics.Bitmap bmp = BitmapFactory.decodeByteArray(plain, 0, plain.length);
            if (bmp == null) { toast("تعذر فتح الصورة"); return; }
            ImageView iv = new ImageView(this); iv.setImageBitmap(bmp); iv.setAdjustViewBounds(true); iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            ScrollView sc = new ScrollView(this); sc.addView(iv);
            new AlertDialog.Builder(this).setTitle("عرض الوثيقة").setView(sc).setPositiveButton("إغلاق",null).show();
        } catch(Exception e) { toast("تعذر فتح الصورة"); }
    }

    private SecretKey getOrCreateKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        if (ks.containsAlias("MyDocsImageKey")) return ((KeyStore.SecretKeyEntry)ks.getEntry("MyDocsImageKey", null)).getSecretKey();
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder("MyDocsImageKey", KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
          .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setRandomizedEncryptionRequired(true).build());
        return kg.generateKey();
    }
    private byte[] encrypt(byte[] plain) throws Exception {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE, getOrCreateKey());
        byte[] iv=c.getIV(); byte[] cipher=c.doFinal(plain); byte[] result=new byte[1+iv.length+cipher.length];
        result[0]=(byte)iv.length; System.arraycopy(iv,0,result,1,iv.length); System.arraycopy(cipher,0,result,1+iv.length,cipher.length); return result;
    }
    private byte[] decrypt(byte[] data) throws Exception {
        int ivLen=data[0]&0xff; byte[] iv=new byte[ivLen]; System.arraycopy(data,1,iv,0,ivLen);
        byte[] cipher=new byte[data.length-1-ivLen]; System.arraycopy(data,1+ivLen,cipher,0,cipher.length);
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE,getOrCreateKey(),new GCMParameterSpec(128,iv)); return c.doFinal(cipher);
    }

    private String hash(String s) {
        try { MessageDigest md = MessageDigest.getInstance("SHA-256"); byte[] b=md.digest(("MyDocs-local-v1:"+s).getBytes("UTF-8")); StringBuilder out=new StringBuilder(); for(byte x:b) out.append(String.format("%02x",x)); return out.toString(); }
        catch(Exception e) { return ""; }
    }
    private void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }
}
